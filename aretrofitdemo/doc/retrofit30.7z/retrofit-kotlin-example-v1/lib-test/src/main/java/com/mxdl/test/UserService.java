package com.mxdl.test;

/**
 * Description: <UserService><br>
 * Author:      mxdl<br>
 * Date:        2020/8/30<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
interface UserService {
    void login(String username,int password);
}
