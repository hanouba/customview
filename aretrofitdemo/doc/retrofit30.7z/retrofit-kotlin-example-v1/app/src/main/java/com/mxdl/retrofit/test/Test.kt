package com.mxdl.retrofit.test

/**
 * Description: <Test><br></br>
 * Author:      mxdl<br></br>
 * Date:        2020/8/21<br></br>
 * Version:     V1.0.0<br></br>
 * Update:     <br></br>
</Test> */
internal object Test {
    @JvmStatic
    fun main(args: Array<String>) {
    }
}