package com.mxdl.retrofit.test

/**
 * Description: <TestV1><br>
 * Author:      mxdl<br>
 * Date:        2020/8/21<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class TestV1 {

}